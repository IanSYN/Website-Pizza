<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Pizzavers | Inscription</title>
    <link rel="stylesheet" href="css/StyleSheet.css">
    <link rel="stylesheet" href="css/cssFormulaire.css">
</head>
