<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Mon panier</title>
        <link rel="stylesheet" href="view/css/style.css" />
    </head>
    <body>
        <?php
        echo "<p>$id</p>";
        echo "<p>$idProd</p>";
        echo "<p>$idPanier</p>";
        ?>
    </body>
</html>
