<div class="conteneurProd">
    <div class="btnRetour">
        <a href="index.php" style="padding: 20px;">Retour</a>
    </div>
    <div style="text-align: center;">
        <p>Ajouter au Panier</p>
        <?php
        echo "<p>$id</p>";
        echo "<p>$val</p>";
        ?>
    </div>
    <div class="Separator">
    </div>
</div>