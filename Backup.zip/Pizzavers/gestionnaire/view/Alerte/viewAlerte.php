<div class='alerte'>
<?php
    echo "<img src='img/ingredient/$cover' />";
    echo "<h3> Stock manquant de $nom </h3>";
    echo "<p> Stock actuel : $stock g </p>";
?>
</div>
