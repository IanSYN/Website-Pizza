<div>
    <?php
    echo "<h1>$nomProduit</h1>";
    echo "<p>$prixProduit €</p>";
    echo "<p>$idCategorie</p>";
    echo "<p>$alAffiche</p>";
    ?>
</div>
</body>