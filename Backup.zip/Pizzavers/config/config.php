<?php
  // indiquez les identifiants de votre base de données IUT
  define("HOSTNAME", "localhost");
  define("DATABASE", "saes3pizzavers");   // votre identifiant court
  define("LOGIN", "saes3pizzavers");      // votre identifiant court
  define("PASSWORD", "zltFcWcsZds/SMCK");      // votre mot de passe
?>