<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>test de connexion</title>
</head>
<body>
    <?php
    require_once ("./connexion.php");
    connexion::connect();
    ?>
</body>
</html>
